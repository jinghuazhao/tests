static inline void ignore_char(char *unused) {(void)unused;}
static inline void ignore_int(int unused) {(void)unused;}

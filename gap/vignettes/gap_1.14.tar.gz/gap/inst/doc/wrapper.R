## -----------------------------------------------------------------------------
library(htmltools)
includeHTML(system.file("extdata", "gap.html", package = "gap"))


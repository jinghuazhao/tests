
The data/ and demo/ directories are with the package root; the following
items are available from there upon installation.

Name           | Description
---------------|----------------------------------------------
CITATION       | Citation information
JAGS/          | JAGS script
REFERENCES.bib | BibTeX bibilgraphy for Rd
ms/            | ms source code associated with read.ms.output
scripts/       | miscellaneous codes
shinygap/      | shiny App

#!/usr/bin/env python3
"""
Simple Multimodal Medical Records Demo
=====================================

This script demonstrates how to work with multimodal medical records
that include both imaging data and textual case histories.

Key components:
1. Loading and preprocessing medical images
2. Processing textual medical reports
3. Combining modalities for analysis
4. Simple prediction examples
"""

import os
import torch
import torch.nn as nn
from PIL import Image
import numpy as np
from typing import Dict, Tuple, List
import json


class MedicalImageProcessor:
    """Process medical images (X-ray, MRI, CT scans, etc.)"""

    def __init__(self):
        # Simple normalization parameters
        self.mean = [0.485, 0.456, 0.406]
        self.std = [0.229, 0.224, 0.225]

    def process_image(self, image_path: str) -> torch.Tensor:
        """
        Load and preprocess a medical image

        Args:
            image_path: Path to the medical image

        Returns:
            Processed image tensor
        """
        try:
            # Load image
            image = Image.open(image_path).convert('RGB')

            # Resize to standard size
            image = image.resize((224, 224))

            # Convert to numpy array and normalize
            img_array = np.array(image).astype(np.float32) / 255.0

            # Normalize with ImageNet statistics
            for i in range(3):
                img_array[:, :, i] = (img_array[:, :, i] - self.mean[i]) / self.std[i]

            # Convert to tensor and rearrange dimensions
            img_tensor = torch.from_numpy(img_array).permute(2, 0, 1)

            return img_tensor.unsqueeze(0)  # Add batch dimension
        except Exception as e:
            print(f"Error processing image {image_path}: {e}")
            # Return a dummy tensor if image loading fails
            return torch.zeros(1, 3, 224, 224)


class TextProcessor:
    """Process medical text reports with simple tokenization"""

    def __init__(self):
        # Simple vocabulary for demonstration
        self.vocab = {
            'patient': 1, 'presents': 2, 'with': 3, 'acute': 4, 'chest': 5,
            'pain': 6, 'and': 7, 'dyspnea': 8, 'vital': 9, 'signs': 10,
            'stable': 11, 'ecg': 12, 'shows': 13, 'st-segment': 14,
            'elevation': 15, 'leads': 16, 'cardiac': 17, 'enzymes': 18,
            'elevated': 19, 'recommend': 20, 'urgent': 21, 'cardiology': 22,
            'consultation': 23, 'coronary': 24, 'angiography': 25,
            'possible': 26, 'diagnosis': 27, 'treatment': 28,
            'further': 29, 'testing': 30, 'recommended': 31,
            'pad': 0  # Padding token
        }
        self.embedding_dim = 128
        self.max_length = 100

    def process_text(self, text: str) -> torch.Tensor:
        """
        Process medical text report with simple tokenization

        Args:
            text: Medical report text

        Returns:
            Text embedding tensor
        """
        # Simple tokenization
        words = text.lower().replace(',', '').replace('.', '').split()

        # Convert words to indices
        indices = []
        for word in words[:self.max_length]:  # Limit length
            indices.append(self.vocab.get(word, 0))  # 0 for unknown words

        # Pad to max_length
        while len(indices) < self.max_length:
            indices.append(0)

        # Create simple embedding (random for demo)
        # In practice, you'd use pre-trained embeddings
        np.random.seed(sum(indices) % 1000)  # Deterministic for demo
        embedding = np.random.randn(self.embedding_dim).astype(np.float32)

        return torch.from_numpy(embedding).unsqueeze(0)  # Add batch dimension


class MultimodalMedicalModel(nn.Module):
    """Simple multimodal model combining image and text features"""

    def __init__(self, image_feature_size: int = 512, text_feature_size: int = 128):
        super().__init__()

        # Simple feature extractor for images
        self.image_extractor = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.AdaptiveAvgPool2d((8, 8))
        )

        # Project image features to standard size
        self.image_project = nn.Linear(64 * 8 * 8, image_feature_size)

        # Feature combination layers
        combined_features = image_feature_size + text_feature_size
        self.classifier = nn.Sequential(
            nn.Linear(combined_features, 256),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(256, 64),
            nn.ReLU(),
            nn.Linear(64, 2)  # Binary classification example
        )

    def forward(self, image_tensor: torch.Tensor, text_embedding: torch.Tensor) -> torch.Tensor:
        """
        Forward pass combining image and text features

        Args:
            image_tensor: Processed image tensor
            text_embedding: Text embedding tensor

        Returns:
            Model output logits
        """
        # Process image features
        image_features = self.image_extractor(image_tensor)
        image_features = image_features.view(image_features.size(0), -1)
        image_features = self.image_project(image_features)

        # Combine features (concatenate along feature dimension)
        combined_features = torch.cat([image_features, text_embedding], dim=1)

        # Classification
        output = self.classifier(combined_features)
        return output


def load_sample_data() -> Tuple[Dict, str]:
    """
    Load sample medical data

    Returns:
        Tuple of (sample record dict, sample text)
    """
    sample_record = {
        "patient_id": "P001",
        "age": 65,
        "gender": "M",
        "symptoms": ["chest pain", "shortness of breath"],
        "diagnosis": "Possible cardiac issue",
        "treatment": "Further testing recommended"
    }

    sample_text = """
    Patient presents with acute chest pain and dyspnea.
    Vital signs stable, ECG shows ST-segment elevation in leads.
    Cardiac enzymes elevated. Recommend urgent cardiology consultation
    and consideration for coronary angiography.
    """

    return sample_record, sample_text


def create_sample_image(path: str):
    """
    Create a sample medical image placeholder

    Args:
        path: Path to save the sample image
    """
    # Create a simple grayscale image that looks medical-like
    img_array = np.random.randint(0, 255, (256, 256), dtype=np.uint8)
    # Add some patterns to make it look more like medical imaging
    center_x, center_y = 128, 128
    for i in range(256):
        for j in range(256):
            distance = np.sqrt((i-center_x)**2 + (j-center_y)**2)
            if distance < 30:
                img_array[i, j] = min(255, img_array[i, j] + 100)

    # Add some linear patterns to simulate bone structures
    for i in range(50, 200):
        img_array[i, 100:160] = np.minimum(img_array[i, 100:160] + 50, 255)

    img = Image.fromarray(img_array, mode='L').convert('RGB')
    img.save(path)


def main():
    """Main demonstration function"""
    print("=== Simple Multimodal Medical Records Demo ===")
    print("This demo showcases how to work with both medical imaging and textual reports.")
    print()

    # Initialize processors
    print("Initializing processors...")
    image_processor = MedicalImageProcessor()
    text_processor = TextProcessor()

    # Create sample data directory
    data_dir = "/home/jhz22/Downloads/multimodal_medical_demo/data"
    os.makedirs(data_dir, exist_ok=True)

    # Create sample image
    sample_image_path = os.path.join(data_dir, "sample_xray.png")
    print(f"Creating sample medical image at {sample_image_path}")
    create_sample_image(sample_image_path)

    # Load sample data
    print("Loading sample medical record...")
    record_data, report_text = load_sample_data()
    print(f"Sample patient: {record_data['patient_id']}, Age: {record_data['age']}")
    print(f"Symptoms: {', '.join(record_data['symptoms'])}")
    print()

    # Process image
    print("Processing medical image...")
    image_tensor = image_processor.process_image(sample_image_path)
    print(f"Image tensor shape: {image_tensor.shape}")

    # Process text
    print("Processing medical text report...")
    text_embedding = text_processor.process_text(report_text)
    print(f"Text embedding shape: {text_embedding.shape}")

    # Initialize multimodal model
    print("\nInitializing multimodal model...")
    model = MultimodalMedicalModel()
    print("Model created successfully!")
    print(f"Model parameters: {sum(p.numel() for p in model.parameters()):,}")

    # Run inference (demo only)
    print("\nRunning inference (demo)...")
    with torch.no_grad():
        output = model(image_tensor, text_embedding)
        prediction = torch.softmax(output, dim=1)

    print(f"Model output shape: {output.shape}")
    print(f"Prediction probabilities: {prediction.numpy()[0]}")
    predicted_class = torch.argmax(prediction, dim=1).item()
    confidence = prediction.numpy()[0][predicted_class]
    print(f"Predicted class: {predicted_class} (confidence: {confidence:.3f})")

    # Save sample record
    record_path = os.path.join(data_dir, "sample_record.json")
    with open(record_path, 'w') as f:
        json.dump(record_data, f, indent=2)
    print(f"\nSample record saved to {record_path}")

    print("\n=== Demo Complete ===")
    print("This demonstration showed:")
    print("1. Loading and preprocessing medical images")
    print("2. Processing textual medical reports")
    print("3. Combining modalities in a neural network")
    print("4. Running inference on multimodal data")
    print("\nNote: This is a simplified demo for educational purposes.")
    print("Real medical applications would require:")
    print("- Proper medical imaging preprocessing")
    print("- Advanced NLP models trained on medical texts")
    print("- Extensive validation and regulatory compliance")
    print("- Clinical expert oversight")


if __name__ == "__main__":
    main()
#!/usr/bin/env python3
"""
Multimodal Medical Records Demo
===============================

This script demonstrates how to work with multimodal medical records
that include both imaging data and textual case histories.

Key components:
1. Loading and preprocessing medical images
2. Processing textual medical reports
3. Combining modalities for analysis
4. Simple prediction examples
"""

import os
import torch
import torch.nn as nn
from PIL import Image
import numpy as np
from transformers import AutoTokenizer, AutoModel
import torchvision.transforms as transforms
from typing import Dict, Tuple, List
import json


class MedicalImageProcessor:
    """Process medical images (X-ray, MRI, CT scans, etc.)"""

    def __init__(self):
        self.transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                               std=[0.229, 0.224, 0.225])
        ])

    def process_image(self, image_path: str) -> torch.Tensor:
        """
        Load and preprocess a medical image

        Args:
            image_path: Path to the medical image

        Returns:
            Processed image tensor
        """
        try:
            # Load image
            image = Image.open(image_path).convert('RGB')
            # Apply transformations
            processed_image = self.transform(image)
            return processed_image.unsqueeze(0)  # Add batch dimension
        except Exception as e:
            print(f"Error processing image {image_path}: {e}")
            # Return a dummy tensor if image loading fails
            return torch.zeros(1, 3, 224, 224)


class TextProcessor:
    """Process medical text reports"""

    def __init__(self, model_name: str = "bert-base-uncased"):
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModel.from_pretrained(model_name)

    def process_text(self, text: str) -> torch.Tensor:
        """
        Process medical text report

        Args:
            text: Medical report text

        Returns:
            Text embedding tensor
        """
        # Tokenize text
        inputs = self.tokenizer(
            text,
            return_tensors="pt",
            truncation=True,
            padding=True,
            max_length=512
        )

        # Get embeddings
        with torch.no_grad():
            outputs = self.model(**inputs)
            # Use pooled output (CLS token)
            embeddings = outputs.pooler_output

        return embeddings


class MultimodalMedicalModel(nn.Module):
    """Simple multimodal model combining image and text features"""

    def __init__(self, image_feature_size: int = 512, text_feature_size: int = 768):
        super().__init__()

        # Image processing layers
        self.image_backbone = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=3, stride=2, padding=1),
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d((1, 1))
        )

        # Feature combination layers
        combined_features = image_feature_size + text_feature_size
        self.classifier = nn.Sequential(
            nn.Linear(combined_features, 512),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(512, 128),
            nn.ReLU(),
            nn.Linear(128, 2)  # Binary classification example
        )

        # Image feature projection to match expected size
        self.image_projection = nn.Linear(128, image_feature_size)

    def forward(self, image_tensor: torch.Tensor, text_embedding: torch.Tensor) -> torch.Tensor:
        """
        Forward pass combining image and text features

        Args:
            image_tensor: Processed image tensor
            text_embedding: Text embedding tensor

        Returns:
            Model output logits
        """
        # Process image features
        image_features = self.image_backbone(image_tensor)
        image_features = image_features.view(image_features.size(0), -1)
        image_features = self.image_projection(image_features)

        # Combine features
        combined_features = torch.cat([image_features, text_embedding], dim=1)

        # Classification
        output = self.classifier(combined_features)
        return output


def load_sample_data() -> Tuple[Dict, str]:
    """
    Load sample medical data

    Returns:
        Tuple of (sample record dict, sample text)
    """
    sample_record = {
        "patient_id": "P001",
        "age": 65,
        "gender": "M",
        "symptoms": ["chest pain", "shortness of breath"],
        "diagnosis": "Possible cardiac issue",
        "treatment": "Further testing recommended"
    }

    sample_text = """
    Patient presents with acute chest pain and dyspnea.
    Vital signs stable, ECG shows ST-segment elevation in leads II, III, and aVF.
    Cardiac enzymes elevated. Recommend urgent cardiology consultation
    and consideration for coronary angiography.
    """

    return sample_record, sample_text


def create_sample_image(path: str):
    """
    Create a sample medical image placeholder

    Args:
        path: Path to save the sample image
    """
    # Create a simple grayscale image that looks medical-like
    img_array = np.random.randint(0, 255, (256, 256), dtype=np.uint8)
    # Add some patterns to make it look more like medical imaging
    center_x, center_y = 128, 128
    for i in range(256):
        for j in range(256):
            distance = np.sqrt((i-center_x)**2 + (j-center_y)**2)
            if distance < 30:
                img_array[i, j] = min(255, img_array[i, j] + 100)

    img = Image.fromarray(img_array, mode='L').convert('RGB')
    img.save(path)


def main():
    """Main demonstration function"""
    print("=== Multimodal Medical Records Demo ===")
    print("This demo showcases how to work with both medical imaging and textual reports.")
    print()

    # Initialize processors
    print("Initializing processors...")
    image_processor = MedicalImageProcessor()
    text_processor = TextProcessor()

    # Create sample data directory
    data_dir = "/home/jhz22/Downloads/multimodal_medical_demo/data"
    os.makedirs(data_dir, exist_ok=True)

    # Create sample image
    sample_image_path = os.path.join(data_dir, "sample_xray.png")
    print(f"Creating sample medical image at {sample_image_path}")
    create_sample_image(sample_image_path)

    # Load sample data
    print("Loading sample medical record...")
    record_data, report_text = load_sample_data()
    print(f"Sample patient: {record_data['patient_id']}, Age: {record_data['age']}")
    print(f"Symptoms: {', '.join(record_data['symptoms'])}")
    print()

    # Process image
    print("Processing medical image...")
    image_tensor = image_processor.process_image(sample_image_path)
    print(f"Image tensor shape: {image_tensor.shape}")

    # Process text
    print("Processing medical text report...")
    text_embedding = text_processor.process_text(report_text)
    print(f"Text embedding shape: {text_embedding.shape}")

    # Initialize multimodal model
    print("\nInitializing multimodal model...")
    model = MultimodalMedicalModel()
    print("Model created successfully!")

    # Run inference (demo only)
    print("\nRunning inference (demo)...")
    with torch.no_grad():
        output = model(image_tensor, text_embedding)
        prediction = torch.softmax(output, dim=1)

    print(f"Model output shape: {output.shape}")
    print(f"Prediction probabilities: {prediction.numpy()[0]}")

    # Save sample record
    record_path = os.path.join(data_dir, "sample_record.json")
    with open(record_path, 'w') as f:
        json.dump(record_data, f, indent=2)
    print(f"\nSample record saved to {record_path}")

    print("\n=== Demo Complete ===")
    print("This demonstration showed:")
    print("1. Loading and preprocessing medical images")
    print("2. Processing textual medical reports with BERT")
    print("3. Combining modalities in a neural network")
    print("4. Running inference on multimodal data")


if __name__ == "__main__":
    main()